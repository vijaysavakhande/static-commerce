<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends EC_Controller {

	public function _construct(){
		parent::_construct();
	}

	public function index()
	{		
		$homejs = [
			'resources/front/js/home.js',
		];
		$this->js = array_merge($this->js,$homejs);
		$this->load->render('home/index');
	}
}
